'use strict';
import React, {Component} from 'react';
import {library} from '@fortawesome/fontawesome-svg-core';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faStroopwafel} from '@fortawesome/free-solid-svg-icons';
import {faBars} from "@fortawesome/free-solid-svg-icons";
import Sidebar from "react-sidebar";
import "../../css/home_page.css";
import '../../css/background_img.css';
import AboutUs_Container from "./AboutUs_Container";
import Ticket_Container from "./Ticket_Container";
import HomeImg from '../../resources/images/home.jpg';
import TrainDetail_Container from "./TrainDetail_Container";
import Contact_Container from "./Contact_Container";
import UpdateUser_Container from "./UpdateUser_Container";
import {Link} from "react-router-dom";
library.add(faStroopwafel);

export default class Home_Container extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sidebarOpen: false,
            menuItem: ""
        };
        this.onSetSidebarOpen = this.onSetSidebarOpen.bind(this);
        this.onUpdateUserClick = this.onUpdateUserClick.bind(this);
        this.onAboutUsClick = this.onAboutUsClick.bind(this);
        this.onBookTicketClick = this.onBookTicketClick.bind(this);
        this.onTrainClick = this.onTrainClick.bind(this);
        this.onContactClick = this.onContactClick.bind(this);
        this.handleToggleMenu = this.handleToggleMenu.bind(this);
    }

    onSetSidebarOpen(open) {
        this.setState({sidebarOpen: open});
    }

    handleToggleMenu() {
        if (this.state.sidebarOpen === false) {
            this.setState({
                sidebarOpen: true
            })
        } else {
            this.setState({
                sidebarOpen: false
            })
        }
    }

    onUpdateUserClick() {
        this.setState({
            menuItem: "updateUser"
        })
    }

    onTrainClick() {
        this.setState({
            menuItem: "train"
        })
    }

    onContactClick() {
        this.setState({
            menuItem: "contact"
        })
    }

    onAboutUsClick() {
        this.setState({
            menuItem: "about_us"
        })
    }

    onBookTicketClick(){
        this.setState({
            menuItem: "tickets"
        })
    }

    render() {
        let menuContent = () => {
            switch (this.state.menuItem) {
                case "updateUser":
                    return <UpdateUser_Container/>;
                    break;
                case "contact":
                    return <Contact_Container/>;
                    break;
                case "about_us":
                    return <AboutUs_Container/>;
                    break;
                case "tickets":
                    return <Ticket_Container/>;
                    break;
                case "train":
                    return <TrainDetail_Container/>;
                    break;
                default:
                    return <div><img src={HomeImg}/></div>
            }
        };
        return <div>
            <div className="navbar">
            </div>
            <Sidebar
                sidebar={
                    <div>
                        <div className="menuTop">
                           <strong><label>Home</label></strong>
                        </div>
                        <br/>
                        <button className="navMenuBtnList" onClick={this.onUpdateUserClick}>Update User</button>
                        <button className="navMenuBtnList" onClick={this.onContactClick}>Contacts</button>
                        <button className="navMenuBtnList" onClick={this.onAboutUsClick}>About Us</button>
                        <button className="navMenuBtnList" onClick={this.onBookTicketClick}>Tickets</button>
                        <button className="navMenuBtnList" onClick={this.onTrainClick}>Trains</button>
                        <Link to="/">
                            <button className="navMenuBtnList">Log Out</button>
                        </Link>
                    </div>}
                open={this.state.sidebarOpen}
                onSetOpen={this.onSetSidebarOpen}
                styles={{sidebar: {background: "black", zIndex: 10}}}
            >
                <button onClick={() => this.handleToggleMenu(false)} className="btnMenu"
                        style={{position: "fixed", zIndex: 10}}>
                    <FontAwesomeIcon icon={faBars}/>
                </button>
                <div style={{marginTop: "40px"}}>
                    {menuContent()}
                </div>
            </Sidebar>
        </div>
    }
}
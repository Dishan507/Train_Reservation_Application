'use strict';
import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import '../../css/background_img.css';
import '../../css/booking.css';
import Payment_Container from "./Payment_Container";
import axios from "axios";

let book_ticket_style = {
    float: 'left',
    marginLeft: '50px',
    marginTop: '50px',
    color: 'White'
};
let btn_styles = {
    marginTop: '20px',
    width: '140px',
    marginLeft: '10px'
};

export default class Book_Ticket_Container extends Component {
    constructor(props) {
        super(props);
        this.onFromChange = this.onFromChange.bind(this);
        this.onToChange = this.onToChange.bind(this);
        this.onPayementClick = this.onPayementClick.bind(this);
        this.state = {
            menuItem: "",
            from: '',
            to: '',
            price: ''
        }
    }

    onSubmit(e) {
        e.preventDefault();
        this.setState({
            from: '',
            to: '',
            price: '',
        })
    }

    onFromChange(e) {
        this.setState({
            from: e.target.value
        });
    }

    onToChange(e) {
        this.setState({
            to: e.target.value
        });
    }

    onPayementClick(){
        this.setState({
            menuItem: "payment"
        })
    }

    componentDidMount() {
        axios.get('http://localhost:4000/train/'+this.props.match.params.id)
            .then(response =>{
                const train_name =response.data.train_name;
                const price = response.data.price;

                this.setState({
                    price: response.data.price,

                });

                console.log(train_name);
                console.log(price);

                document.getElementById("a").innerHTML="You chose train "+ train_name;
                document.getElementById("b").innerHTML= + price;
            }).catch(function (error) {
            console.log(error)
        })
    }
    onSubmit(e){
        e.preventDefault();
        calculation();



        function calculation() {

            let f1 = document.getElementById("price").value;
            let f2 = document.getElementById("number").value;

            let result = parseFloat(f1)* parseFloat(f2);
            if(!isNaN(result)){
                document.getElementById("answer").innerHTML="Total Price: Rs "+ result+".00";
            }

            alert("Calculated successfully");
            console.log(result);

        }

    }

    render() {
        switch (this.state.menuItem) {
            case "payment":
                return <Payment_Container/>;
                break;
            default:
                return <div>
                    <div className="Ticket_Container">
                        <form onSubmit={this.onSubmit}>
                            <div className="form-group" style={book_ticket_style}>
                                <center><h3>Book Ticket</h3></center>
                                <div className="row">
                                    <div className="col-sm-6">
                                        <label>From: </label>
                                        <input type="text"
                                               className="form-control"
                                               value={this.state.from}
                                               onChange={this.onFromChange}
                                               required="required"
                                        />
                                    </div>
                                    <div className="col-sm-6">
                                        <label>To: </label>
                                        <input type="text"
                                               className="form-control"
                                               value={this.state.to}
                                               onChange={this.onToChange}
                                               required="required"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <h2 className="text-primary" id="a"></h2>
                                    <div className="form-group">
                                        <label>Ticket Price:</label>
                                        <input  type="text"
                                                className="form-control"
                                                id="price"
                                                value={this.state.price}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Number of Tickets:</label>
                                        <input  type="text"
                                                className="form-control"
                                                id="number"


                                        />
                                    </div>
                                    <div className="form-group">
                                        <input type="submit" value="Pay" className="btn btn-primary"
                                               value="Get price" style={btn_styles}/>
                                        <input type="submit" value="Pay" className="btn btn-primary"
                                               onClick={this.onPayementClick} style={btn_styles}/>
                                    </div>
                                    <h6 id="a"></h6>
                                    <br/>
                                    <h6 id="answer"></h6>
                                    <br/>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
        }

    }
}

'use strict';
import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import '../../css/background_img.css';
import '../../css/booking.css';
import Book_Ticket_Container from "./Book_Ticket_Container";
let btn_styles = {
    marginTop: '40px',
    width: '140px',
    marginLeft: '50px'
};

export default class Ticket_Container extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuItem: ""
        };
        this.onBookTicketClick = this.onBookTicketClick.bind(this);
    }
    onBookTicketClick(){
        this.setState({
            menuItem: "book_ticket"
        })
    }

    onMyBookingClick(){
        window.confirm("This will show the list of user's bookings");
    }

    onCancelTicketClick(){
        window.confirm("This will cancel ticket if user want");
    }

    render() {
        switch (this.state.menuItem) {
            case "book_ticket":
                return <Book_Ticket_Container/>;
                break;
            default:
                return <div>
                    <div className="Ticket_Container">
                        <div> <input type="button" value="Book Ticket" className="btn btn-primary"
                                     onClick={this.onBookTicketClick} style={btn_styles}/>
                        </div>
                        <div> <input type="button" value="My Booking" className="btn btn-primary"
                                     onClick={this.onMyBookingClick} style={btn_styles}/>
                        </div>
                        <div> <input type="button" value="Cancel Ticket" className="btn btn-primary"
                                     onClick={this.onCancelTicketClick} style={btn_styles}/>
                        </div>
                    </div>
                </div>
        }
    }
}
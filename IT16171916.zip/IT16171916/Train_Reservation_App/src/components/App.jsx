'use strict';
import React from 'react';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import * as ReactDOM from "react-dom";
import Register_Container from "./Register_Container";
import Login_Container from "./Login_Container";
import Home_Container from "./Home_Container";
ReactDOM.render((
    <Router>
        <Route path="/" exact component={Login_Container}/>
        <Route path="/register" exact component={Register_Container}/>
        <Route path="/home" exact component={Home_Container}/>
    </Router>
), document.getElementById('root'));



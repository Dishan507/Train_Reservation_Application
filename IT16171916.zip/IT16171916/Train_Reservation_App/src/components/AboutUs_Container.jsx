'use strict';
import React, {Component} from 'react';
import '../../css/about.css';
import "bootstrap/dist/css/bootstrap.min.css";
import '../../css/network.css';
import Img from '../../resources/images/root.jpg';
let _style = {
    color: 'white',
    width: '240px',
    float: 'left',
    marginTop: '80px',
    marginLeft: '200px'
};
export default class AboutUs_Container extends Component {
    componentDidMount() {
    }

    constructor(props) {
        super(props);
        this.onOurNetworkClick = this.onOurNetworkClick.bind(this);
        this.state = {
            menuItem: ""
        }
    }

    onOverviewClick(){
        window.confirm("Overview\n\nSri Lanka Railways ( SLR ) is a government department functioning under the Ministry of Transport. It is a major transport service provider and is the only rail transport organization in the country. SLR transports both passenger and freight. At its inception, railway was carrying more freight than passenger. But today, it is passenger oriented. SLR’s market share for passenger transport is about 6.0 % and about 0.7 % for goods transport.\n" +
            "\n" +
            "In Sri Lanka, the service provided by SLR in carrying the daily commuters to their workplaces, is inevitable. Sri Lanka Railway operates approximately 396 trains which include 67 Long-Distance and 16 Intercity trains and carries about 3.72 Million passengers daily.\n" +
            "\n" +
            "SLR owns and maintains 1561km of rail tracks, 72 locomotives,power sets 78, 565 carriages and the signalling network. At present, it has a workforce of 17,634.\n" +
            "\n" +
            "Sri Lanka Railways ( SLR ) functions under the General Manager of Railways (GMR). The General Manager reports to the Secretary of the Ministry of Transport.\n" +
            "\n" +
            "SLR has been divided into ten Sub Departments and three Units. Sub departments are managed by the Heads of the Sub Departments who reports directly to the General Manager of Railways.");
    }
    onHistoryClick(){
        window.confirm("History\n\nRail was introduced in Sri Lanka in 1864 to transport coffee from plantations in the hill country district of Kandy to the port city of Colombo on its way to Europe and the world market. The coffee blight of 1871 destroyed many a fine plantation and tea replaced coffee. With the development of tea plantations in the 1880s, the joint stock companies swallowed up the former individual proprietorship of the coffee era. Under corporate ownership and management control by companies, the process of production of tea became more sophisticated and needed more and more railways built to the Kandyan highlands. To send tea to Colombo and to transport labour, machinery, manure, rice and foodstuff, etc to Kandy, another 100 miles of railways were constructed in the tea planting districts to serve the expanding tea domain\nTo serve the coconut plantations flourishing in the west, south west and north west coastal areas of the country, and the wet inland rubber plantations below the tea belt, railway lines were built in the wake of these agricultural developments. Thereafter, the need for cheap and safe travel in order to open up the hinterland of the country led to the expansion of the railway.\n" +
            "\n" +
            "An extension of the Main Line to Kandy was made north to the ancient city of Anuradhapura, going further north to Kankesanturai and west to Talaimannar to connect the island with South India by ferry, to bring Indian labour for the tea and rubber plantations, and also import rice and other food stuffs not indigenously produced in sufficient quantities.\nTowards the east, there was little economic justification to lay a line to the dry zone in that direction, but it became strategically worthwhile to lay a line to the natural harbour of Trincomalee and also connect it to the provincial capital of Batticaloa. These lines were laid with light (21 kg) section rails, as was the narrow gauge section to serve the rubber plantations east of Colombo, known as the Kelani Valley Line.\nUp country, a similar branch line was laid from Nanu Oya on the Main Line through very difficult terrain to serve the tea plantations around Nuwara Eliya. Track alignment was defined in this section about 140 years ago, when economic considerations were vastly different. The railways achieved modal superiority with speeds of 25 to 40 kmph in the hill country and 65 to 80 in the low country and civil engineering criteria was influenced by the economic need to minimize cuts and fills, permitting gradients to 2 to 3 % and minimizing bridge lengths. As a result, the alignment here is winding with very sharp curves.\n" +
            "\n" +
            "In the early days of the railways, the bulk of the freight was carried to the port of Colombo and as the port expanded, rail lines were laid to serve every pier.");
    }
    onFuturePlanClick(){
        window.confirm("Future Plans\n\nIncreasing operating speed from 80 km/h to 100 km/h\n" +
            "Construction of new Railway lines\n" +
            "Increasing of Rolling Stock fleet\n" +
            "Rehabilitation of Signalling and Telecommunication\n" +
            "Electrification\n" +
            "Information Technology\n" +
            "Increasing operating speed from 80 km/h to 100 km/h");
    }

    onOurNetworkClick(){
        this.setState({
            menuItem: "network"
        })
    }

    render() {
        switch (this.state.menuItem) {
            case "network":
                return <div>
                    <div className="Network_Container"><img src={Img}/></div>
                </div>;
            break;
            default:
                return <div>
                    <div className="AboutUs_Container">
                        <div style={_style}>
                            <u><h2>
                                <text onClick={this.onOverviewClick}>Overview</text>
                            </h2></u>
                            <u><h2>
                                <text onClick={this.onHistoryClick}>History</text>
                            </h2></u>
                            <u><h2>
                                <text onClick={this.onFuturePlanClick}>Future Plan</text>
                            </h2></u>
                            <u><h2>
                                <text onClick={this.onOurNetworkClick}>Our Network</text>
                            </h2></u>
                        </div>
                    </div>
                </div>;
        }
    }
}
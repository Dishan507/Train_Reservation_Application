/*
 *Sampath_Container Component
 * sampath component when the user clicks the sampath payment button on the payment page this omponent is rendered
 */

import React, {Component} from 'react';
import axios from "axios";
import '../../css/blueBack.css';

export default class Sampath_Container extends Component{

    constructor(props){
        super(props);

        this.onChangeCName = this.onChangeCName.bind(this);
        this.onChangeCardNumber = this.onChangeCardNumber.bind(this);
        this.onChangeCvv = this.onChangeCvv.bind(this);
        this.onChangeCash = this.onChangeCash.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            card_holder_name: '',
            card_number: '',
            cvv:'',
            cash_in_point:'',
            login_completed: false

        }
    }

    onChangeCName(e){
        this.setState({
            card_holder_name: e.target.value
        })
    }

    onChangeCardNumber(e){
        this.setState({
            card_number: e.target.value
        })
    }

    onChangeCvv(e){
        this.setState({
            cvv: e.target.value
        })
    }

    onChangeCash(e){
        this.setState({
            cash_in_point: e.target.value
        })
    }

    onSubmit(e){
        e.preventDefault();

        console.log(`login success`);
        console.log(`username is:${this.state.cvv}`);
        console.log(`password is:${this.state.card_number}`);

        const newPayment = {
            card_holder_name: this.state.card_holder_name,
            card_number:this.state.card_number,
            cvv:this.state.cvv,
            cash_in_point:this.state.cash_in_point,
            Spayment_completed:this.state.Spayment_completed
        }

        axios.post('http://localhost:4000/sampath_payment/add', newPayment)
            .then(res => console.log(res.data));
        alert("credit Card payment done");

        this.props.history.push('/Home');

        this.setState({
            card_holder_name: '',
            card_number: '',
            cvv:'',
            cash_in_point:'',
            Spayment_completed: false
        })
    }
    render() {
        return(
            <div className="Background_Container" style={{marginTop: 20}}>
                <h2 className="text-info bg-light">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sampath Credit Payment</h2>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Card Holder's Name:</label>
                        <input  type="text"
                                className="form-control"
                                value={this.state.card_holder_name}
                                onChange={this.onChangeCName}
                        />
                    </div>

                    <div className="form-group">
                        <label>Card Number:</label>
                        <input  type="number"
                                className="form-control"
                                value={this.state.card_number}
                                onChange={this.onChangeCardNumber}
                        />
                    </div>

                    <div className="form-group">
                        <label>CVV:</label>
                        <input  type="number"
                                className="form-control"
                                value={this.state.cvv}
                                onChange={this.onChangeCvv}
                        />
                    </div>

                    <div className="form-group">
                        <label>Cash in point:</label>
                        <input  type="number"
                                className="form-control"
                                value={this.state.cash_in_point}
                                onChange={this.onChangeCash}
                        />
                    </div>
                    <div className="form-group">
                        <input  type="submit"
                                className="btn btn-primary"
                                value="Pay"
                        />
                    </div>
                </form>
            </div>
        )
    }

}
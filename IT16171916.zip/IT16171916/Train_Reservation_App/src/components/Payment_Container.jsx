'use strict';
import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import '../../css/background_img.css';
import '../../css/payment_page.css';
import Dialog_Container from "./Dialog_Container";
import Sampath_Container from "./Sampath_Container";
let payment_style = {
    float: 'left',
    marginTop: '200px',
    color: 'Black'
};
let payment_btn_styles = {
    width: '140px',
    marginLeft: '50px',
    marginTop: '30px'
};

export default class Payment_Container extends Component {
    constructor(props) {
        super(props);
        this.onCreditCardChange = this.onCreditCardChange.bind(this);
        this.onMobilePayChange = this.onMobilePayChange.bind(this);
        this.state = {
            menuItem: ""
        }
    }

    onCreditCardChange(){
        this.setState({
            menuItem: "creditCard"
        })
    }

    onMobilePayChange(){
        this.setState({
            menuItem: "mobilePay"
        })
    }

    render() {
        switch (this.state.menuItem) {
            case "creditCard":
                return <Sampath_Container/>;
                break;
            case "mobilePay":
                    return <Dialog_Container/>;
                break;
            default:
                return <div className="Payment_Container">
                    <div className="form-group">
                        <div style={payment_style}>
                            <center><h3>Payment Method</h3></center>
                            <input type="submit" value="Credit Card" className="btn btn-primary"
                                   onClick={this.onCreditCardChange} style={payment_btn_styles}/>
                            <input type="submit" value="Mobile Pay" className="btn btn-primary"
                                   onClick={this.onMobilePayChange} style={payment_btn_styles}/>
                        </div>

                    </div>
                </div>
        }
    }
}
/////////////////////Steps to Deploy////////////////////////

*To reduce the file size, I removed .idea folder,node_modules folder, dist folder, etc. So install needed things to project (E.g:- npm istall). Otherwise the project will not run as expected

* Train_Reservation_App which includes server backend and React client side
* Per conditions running this project
	*webstrom IDE
	*monogo db database
	*eclips IDE Developer studio

* Open file name Train_Reservation_App in webstrom 
* cd Train_Reservation_App 
* run npm start command
* cd Train_Reservation_Backend (Train_Reservation_Backend is the other backend. It inside the Train_Reservation_App project)
* run node server command

*For Login/Register, I created another backend project. So before login and register to the system, you need to open LoginRegister_Backend project and start the server

* import WSO2 Enterprise Integration project into eclips IDE Developer studio

* Can import relvat monogo db collections using under commands
run mongod command to run mongodb 
run mongo command to run mongodb

*I export some nessasary data from mongodb in 'mongodb database' folder. You need import them. (dpaymentOut,spaymentOut, trainsOut, usersOut file need to import). Otherwise Train details, Contact details, etc. will not display. Also it will not go to the payment method and UpdateUser pages, because in these componens get some paramiters from the database. 

*For other information I included in the report. (IT16171916_Report as a pdf)

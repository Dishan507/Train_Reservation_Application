const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const UserRoutes = express.Router();
const PORT = 5000;
const server = require("repl");

app.use(cors());
app.use(bodyParser.json());
app.use('/users', UserRoutes);

mongoose.connect('mongodb://127.0.0.1:27017/trainApp', {useNewUrlParser: true})
    .then(() => {
        return server.start();
    }).catch(err => {
    console.error(err);
    process.exit(1);
});

const connection = mongoose.connection;


connection.once('open', function () {
    console.log('MongoDB database connection established successfully');
});

require('./api/routes/login-register')(app);


app.listen(PORT, function () {
    console.log("Server is Running on Port : " + PORT);
});
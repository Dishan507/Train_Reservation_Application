const User = require('../../module/user');
module.exports = (app) => {
    app.post('/users/create-user', (req, res, next) => {
        let fName = req.body.fName;
        let lName = req.body.lName;
        let email = req.body.email;
        let address = req.body.address;
        let tp = req.body.tp;
        let pwd = req.body.pwd;
        let nic = req.body.nic;
        let accType = req.body.accType;

        if (!fName) {
            return res.send({
                success: false,
                message: 'Error : First Name Cannot be Empty !'
            });
        }
        if (!lName) {
            return res.send({
                success: false,
                message: 'Error : Last Name Cannot be Empty !'
            });
        }
        if (!email) {
            return res.send({
                success: false,
                message: 'Error : Email Cannot be Empty !'
            });
        }
        if (!address) {
            return res.send({
                success: false,
                message: 'Error : Address Cannot be Empty !'
            });
        }
        if (!tp) {
            return res.send({
                success: false,
                message: 'Error : TP Cannot be Empty !'
            });
        }
        if (!pwd) {
            return res.send({
                success: false,
                message: 'Error : Password Cannot be Empty !'
            });
        }

        email = email.toLowerCase();

        User.find({email: email}, (err, previousUsers) => {
            if (err) {
                return res.send('Error : Server Error !');
            } else if (previousUsers.length > 0) {
                return res.send('Error : Account Already exists !');
            }
            const newUser = new User();
            newUser.fName = fName;
            newUser.lName = lName;
            newUser.email = email;
            newUser.address = address;
            newUser.tp = tp;
            newUser.pwd = newUser.generateHash(pwd);
            newUser.nic = nic;
            newUser.accType = accType;
            newUser.save((err, user) => {
                if (err) {
                    return res.send({
                        success: false,
                        message: 'Error : Server Error'
                    });
                }
                return res.send({
                    success: true,
                    message: 'Successfully Registered !',
                    user: user
                })
            })
        })
    });

    app.post('/users/login-check', (req, res, next) => {

        let email = req.body.user_email;
        let pwd = req.body.user_pwd;

        if (!email) {
            return res.send({
                success: false,
                message: 'Error : Email Cannot be Empty !'
            });
        }
        if (!pwd) {
            return res.send({
                success: false,
                message: 'Error : Password Cannot be Empty !'
            });
        }
        User.find({email: email}, (err, users) => {
            if (err) {
                return res.send({
                    success: false,
                    message: 'Error : Server Error'
                });
            }
            if (users.length != 1) {
                return res.send({
                    success: false,
                    message: 'Error : Invalid'
                });
            }

            const user = users[0];
            if (!user.validPassword(pwd, user.pwd)) {
                return res.send({
                    success: false,
                    message: 'Error : Invalid'
                });
            }

            return res.send({
                success: true,
                message: 'Successfully Logged In'
            })


        });

    });

}